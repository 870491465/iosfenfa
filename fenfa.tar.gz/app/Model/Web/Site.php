<?php


namespace App\Model\Web;


class Site
{

}