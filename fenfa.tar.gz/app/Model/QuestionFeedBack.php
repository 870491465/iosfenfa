<?php


namespace App\Model;


use App\Model\Zds\BaseModel;

class QuestionFeedBack extends BaseModel
{

}