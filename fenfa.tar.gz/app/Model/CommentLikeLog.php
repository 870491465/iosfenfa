<?php


namespace App\Model;


use App\Model\Zds\BaseModel;

class CommentLikeLog extends BaseModel
{

}